// ╔═══════════════════════════════════════════════════════════════════════════════════╗
// ║                           البيانات الافتراضية - States                            ║
// ╚═══════════════════════════════════════════════════════════════════════════════════╝

// ═══════════════════════════════════════════════════════════════════════════════════
// أنواع المساحات الافتراضية
// ═══════════════════════════════════════════════════════════════════════════════════
export const defaultItemTypes = {
  floor: { id: 'floor', name: 'أرضية', icon: '⬇️', color: '#10b981', formula: 'length * width', formulaDisplay: 'ط × ع', unit: 'م²', description: 'مساحة الأرضية', enabled: true },
  walls4: { id: 'walls4', name: '4 جدران', icon: '🧱', color: '#3b82f6', formula: '(length + width) * 2 * height', formulaDisplay: '(ط+ع)×2×ر', unit: 'م²', description: 'مساحة 4 جدران', enabled: true },
  wall1: { id: 'wall1', name: 'جدار واحد', icon: '▬', color: '#06b6d4', formula: 'length * height', formulaDisplay: 'ط × ر', unit: 'م²', description: 'مساحة جدار واحد', enabled: true },
  ceiling: { id: 'ceiling', name: 'سقف', icon: '⬆️', color: '#8b5cf6', formula: 'length * width', formulaDisplay: 'ط × ع', unit: 'م²', description: 'مساحة السقف', enabled: true },
  perimeter: { id: 'perimeter', name: 'محيط', icon: '📏', color: '#ec4899', formula: '(length + width) * 2', formulaDisplay: '(ط+ع)×2', unit: 'م.ط', description: 'محيط الغرفة', enabled: true },
  unit: { id: 'unit', name: 'وحدة', icon: '🔢', color: '#f97316', formula: 'quantity', formulaDisplay: 'العدد', unit: 'وحدة', description: 'عدد الوحدات', enabled: true }
};

// ═══════════════════════════════════════════════════════════════════════════════════
// الأماكن الافتراضية
// ═══════════════════════════════════════════════════════════════════════════════════
export const defaultPlaces = {
  dry: { id: 'dry', name: 'أماكن جافة', icon: '🏠', enabled: true, places: ['صالة', 'غرفة نوم', 'غرفة نوم رئيسية', 'غرفة معيشة', 'مجلس', 'ممر', 'مدخل', 'مكتب'] },
  wet: { id: 'wet', name: 'أماكن رطبة', icon: '💧', enabled: true, places: ['مطبخ', 'دورة مياه', 'دورة مياه رئيسية', 'مغسلة', 'غرفة غسيل'] },
  outdoor: { id: 'outdoor', name: 'أماكن خارجية', icon: '🌳', enabled: true, places: ['حوش', 'سطح', 'بلكونة', 'موقف سيارات', 'حديقة', 'ملحق خارجي'] }
};

// ═══════════════════════════════════════════════════════════════════════════════════
// بنود العمل الافتراضية
// ═══════════════════════════════════════════════════════════════════════════════════
export const defaultWorkItems = {
  tiles: {
    name: 'بلاط', icon: '🔲', code: 'BL',
    items: [
      { id: 't1', num: '01', name: 'تركيب بلاط أرضيات', desc: 'تركيب بلاط سيراميك أو بورسلان', exec: 35, cont: 25, typeId: 'floor' },
      { id: 't2', num: '02', name: 'تركيب بلاط جدران', desc: 'تركيب بلاط جدران', exec: 45, cont: 32, typeId: 'walls4' },
      { id: 't3', num: '03', name: 'إزالة بلاط', desc: 'إزالة بلاط قديم', exec: 15, cont: 10, typeId: 'floor' }
    ]
  },
  paint: {
    name: 'دهان', icon: '🎨', code: 'DH',
    items: [
      { id: 'p1', num: '01', name: 'دهان جدران', desc: 'دهان جدران وجهين', exec: 18, cont: 12, typeId: 'walls4' },
      { id: 'p2', num: '02', name: 'دهان سقف', desc: 'دهان أسقف', exec: 15, cont: 10, typeId: 'ceiling' },
      { id: 'p3', num: '03', name: 'معجون وتجهيز', desc: 'معجون وصنفرة', exec: 12, cont: 8, typeId: 'walls4' }
    ]
  },
  plumbing: {
    name: 'سباكة', icon: '🚿', code: 'SB',
    items: [
      { id: 's1', num: '01', name: 'تمديد نقطة مياه', desc: 'تمديد نقطة مياه باردة أو حارة', exec: 150, cont: 100, typeId: 'unit' },
      { id: 's2', num: '02', name: 'تركيب خلاط', desc: 'تركيب خلاط مغسلة أو دش', exec: 80, cont: 50, typeId: 'unit' },
      { id: 's3', num: '03', name: 'تركيب مغسلة', desc: 'تركيب مغسلة كاملة', exec: 200, cont: 120, typeId: 'unit' }
    ]
  },
  electrical: {
    name: 'كهرباء', icon: '⚡', code: 'KH',
    items: [
      { id: 'e1', num: '01', name: 'تمديد نقطة كهرباء', desc: 'تمديد نقطة إضاءة أو بريزة', exec: 120, cont: 80, typeId: 'unit' },
      { id: 'e2', num: '02', name: 'تركيب لوحة كهرباء', desc: 'تركيب لوحة توزيع', exec: 500, cont: 350, typeId: 'unit' }
    ]
  },
  gypsum: {
    name: 'جبس', icon: '🏗️', code: 'JB',
    items: [
      { id: 'g1', num: '01', name: 'جبس أسقف', desc: 'تركيب جبس بورد أسقف', exec: 55, cont: 40, typeId: 'ceiling' },
      { id: 'g2', num: '02', name: 'جبس جدران', desc: 'تركيب جبس بورد جدران', exec: 45, cont: 32, typeId: 'walls4' }
    ]
  }
};

// ═══════════════════════════════════════════════════════════════════════════════════
// البرمجة الافتراضية
// ═══════════════════════════════════════════════════════════════════════════════════
export const defaultProgramming = {
  dry: {
    tiles: { enabled: true, items: ['t1', 't3'] },
    paint: { enabled: true, items: ['p1', 'p2', 'p3'] },
    plumbing: { enabled: false, items: [] },
    electrical: { enabled: true, items: ['e1'] },
    gypsum: { enabled: true, items: ['g1', 'g2'] }
  },
  wet: {
    tiles: { enabled: true, items: ['t1', 't2', 't3'] },
    paint: { enabled: true, items: ['p2'] },
    plumbing: { enabled: true, items: ['s1', 's2', 's3'] },
    electrical: { enabled: true, items: ['e1'] },
    gypsum: { enabled: false, items: [] }
  },
  outdoor: {
    tiles: { enabled: true, items: ['t1', 't3'] },
    paint: { enabled: true, items: ['p1'] },
    plumbing: { enabled: false, items: [] },
    electrical: { enabled: true, items: ['e1'] },
    gypsum: { enabled: false, items: [] }
  }
};
