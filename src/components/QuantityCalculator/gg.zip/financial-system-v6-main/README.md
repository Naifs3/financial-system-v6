# نظام الإدارة المالية 💰

نظام متكامل لإدارة المصروفات والمهام والحسابات.

## المميزات ✨

- 📊 لوحة تحكم شاملة
- 💵 إدارة المصروفات مع تنبيهات الاستحقاق
- ✅ إدارة المهام والمتابعة
- 🔐 إدارة الحسابات وكلمات المرور
- 📁 أرشفة المصروفات
- 📝 سجل الأنشطة
- 🌙 الوضع الليلي
- 📱 متجاوب مع جميع الأجهزة

## التثبيت المحلي 🖥️

```bash
# استنساخ المشروع
git clone https://github.com/YOUR_USERNAME/financial-system.git

# الدخول للمجلد
cd financial-system

# تثبيت المكتبات
npm install

# تشغيل المشروع
npm start
```

## النشر على Vercel 🚀

### الطريقة 1: عبر GitHub (مُوصى بها)

1. أنشئ حساب على [GitHub](https://github.com) إن لم يكن لديك
2. أنشئ مستودع جديد (Repository)
3. ارفع ملفات المشروع:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/financial-system.git
   git push -u origin main
   ```
4. اذهب إلى [vercel.com](https://vercel.com)
5. سجل دخول بحساب GitHub
6. اضغط "New Project"
7. اختر المستودع الذي أنشأته
8. اضغط "Deploy"
9. انتظر دقيقة وسيكون موقعك جاهز! 🎉

### الطريقة 2: عبر Vercel CLI

```bash
# تثبيت Vercel CLI
npm install -g vercel

# تسجيل الدخول
vercel login

# النشر
vercel

# للنشر الإنتاجي
vercel --prod
```

## النشر على Netlify 🌐

1. اذهب إلى [netlify.com](https://netlify.com)
2. سجل دخول بحساب GitHub
3. اضغط "New site from Git"
4. اختر GitHub ثم المستودع
5. في إعدادات البناء:
   - Build command: `npm run build`
   - Publish directory: `build`
6. اضغط "Deploy site"

## بيانات الدخول للتجربة 🔑

| المستخدم | كلمة المرور |
|---------|-------------|
| نايف | 123456 |
| منوّر | 123456 |

## التقنيات المستخدمة 🛠️

- React 18
- Tailwind CSS
- Lucide Icons

## الترخيص 📄

MIT License

---

صُنع بـ ❤️
